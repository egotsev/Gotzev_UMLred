/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.sequenceDiagram.tests;

import junit.framework.TestCase;

import org.elsys.sequenceDiagram.MidlineCombinedFragment;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Midline Combined Fragment</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class MidlineCombinedFragmentTest extends TestCase {

	/**
	 * The fixture for this Midline Combined Fragment test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MidlineCombinedFragment fixture = null;

	/**
	 * Constructs a new Midline Combined Fragment test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MidlineCombinedFragmentTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Midline Combined Fragment test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(MidlineCombinedFragment fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Midline Combined Fragment test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MidlineCombinedFragment getFixture() {
		return fixture;
	}

} //MidlineCombinedFragmentTest
