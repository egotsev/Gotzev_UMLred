/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.sequenceDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Loop Combined Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.sequenceDiagram.SequenceDiagramPackage#getLoopCombinedFragment()
 * @model
 * @generated
 */
public interface LoopCombinedFragment extends OptionalCombinedFragment {
} // LoopCombinedFragment
