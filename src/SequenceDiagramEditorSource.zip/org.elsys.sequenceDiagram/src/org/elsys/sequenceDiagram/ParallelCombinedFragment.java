/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.sequenceDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parallel Combined Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.sequenceDiagram.SequenceDiagramPackage#getParallelCombinedFragment()
 * @model
 * @generated
 */
public interface ParallelCombinedFragment extends CombinedFragment, MidlineCombinedFragment {

} // ParallelCombinedFragment
