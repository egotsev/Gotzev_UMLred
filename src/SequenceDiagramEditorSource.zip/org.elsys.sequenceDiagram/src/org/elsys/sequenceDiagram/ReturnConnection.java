/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.sequenceDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Return Connection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.sequenceDiagram.SequenceDiagramPackage#getReturnConnection()
 * @model
 * @generated
 */
public interface ReturnConnection extends Connection {
} // ReturnConnection
