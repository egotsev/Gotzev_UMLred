/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.sequenceDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Option Combined Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.sequenceDiagram.SequenceDiagramPackage#getOptionCombinedFragment()
 * @model
 * @generated
 */
public interface OptionCombinedFragment extends OptionalCombinedFragment {
} // OptionCombinedFragment
