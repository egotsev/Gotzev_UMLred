/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.elsys.sequenceDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Alternative Combined Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.elsys.sequenceDiagram.SequenceDiagramPackage#getAlternativeCombinedFragment()
 * @model
 * @generated
 */
public interface AlternativeCombinedFragment extends OptionalCombinedFragment, MidlineCombinedFragment {

} // AlternativeCombinedFragment
